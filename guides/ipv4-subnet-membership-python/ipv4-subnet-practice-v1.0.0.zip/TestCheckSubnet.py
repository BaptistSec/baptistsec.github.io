"""Run local fictional IPv4 exercises. No packages or network access needed."""
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
SCRIPT = ROOT / "CheckSubnet.py"


class SubnetChecks(unittest.TestCase):
    def check_bytes(self, data, network, code, output=None, error=None):
        with tempfile.TemporaryDirectory(prefix="subnet-practice-") as folder:
            source = Path(folder) / "addresses with spaces.txt"
            source.write_bytes(data)
            result = subprocess.run([sys.executable, str(SCRIPT), str(source), network],
                                    capture_output=True, text=True, timeout=10)
            self.assertEqual(source.read_bytes(), data, "Input changed")
            self.assertEqual(result.returncode, code, result.stderr)
            if output is not None:
                self.assertEqual(result.stdout, output)
            if error is not None:
                self.assertIn(error, result.stderr)
                self.assertEqual(result.stdout, "")
            else:
                self.assertEqual(result.stderr, "")
            return result

    def test_pinned_program(self):
        self.assertEqual(hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
                         "408beb12b9a57407c293748721ed067036882ee5690cdb2f44d3ad9165de3096")

    def test_main_example(self):
        p = ROOT / "addresses.txt"
        data = p.read_bytes()
        self.check_bytes(data, "192.0.2.0/24", 1,
                         "Line 1: 192.0.2.0 inside\nLine 2: 192.0.2.10 inside\nLine 3: 192.0.2.255 inside\nLine 4: 198.51.100.20 outside\nLine 5: invalid IPv4 address\nNetwork: 192.0.2.0/24; inside: 3; outside: 1; invalid: 1\n")
        self.assertEqual(p.read_bytes(), data)

    def test_smaller_ranges(self):
        p = ROOT / "small-addresses.txt"
        data = p.read_bytes()
        self.check_bytes(data, "192.0.2.0/31", 0,
                         "Line 1: 192.0.2.0 inside\nLine 2: 192.0.2.1 inside\nLine 3: 192.0.2.2 outside\nNetwork: 192.0.2.0/31; inside: 2; outside: 1; invalid: 0\n")
        self.check_bytes(data, "192.0.2.1/32", 0,
                         "Line 1: 192.0.2.0 outside\nLine 2: 192.0.2.1 inside\nLine 3: 192.0.2.2 outside\nNetwork: 192.0.2.1/32; inside: 1; outside: 2; invalid: 0\n")
        self.check_bytes(data, "192.0.2.1/24", 2, error="has host bits set")
        self.assertEqual(p.read_bytes(), data)

    def test_outside_and_empty(self):
        for name, out in [("outside-only.txt", "Line 1: 198.51.100.20 outside\nNetwork: 192.0.2.0/24; inside: 0; outside: 1; invalid: 0\n"),
                          ("empty.txt", "Network: 192.0.2.0/24; inside: 0; outside: 0; invalid: 0\n")]:
            with self.subTest(file=name):
                p = ROOT / name
                data = p.read_bytes()
                self.check_bytes(data, "192.0.2.0/24", 0, out)
                self.assertEqual(p.read_bytes(), data)

    def test_invalid_lines(self):
        for data in [b"192.0.2.01\n", b"2001:db8::1\n", b"invalid\n", b"\n", b"   \n"]:
            with self.subTest(data=data):
                self.check_bytes(data, "192.0.2.0/24", 1,
                                 "Line 1: invalid IPv4 address\nNetwork: 192.0.2.0/24; inside: 0; outside: 0; invalid: 1\n")

    def test_blank_internal_line(self):
        self.check_bytes(b"192.0.2.1\n\n192.0.2.2\n", "192.0.2.0/24", 1,
                         "Line 1: 192.0.2.1 inside\nLine 2: invalid IPv4 address\nLine 3: 192.0.2.2 inside\nNetwork: 192.0.2.0/24; inside: 2; outside: 0; invalid: 1\n")

    def test_bom_whitespace_and_duplicates(self):
        self.check_bytes(b"\xef\xbb\xbf 192.0.2.1 \r\n192.0.2.1\r\n", "192.0.2.0/24", 0,
                         "Line 1: 192.0.2.1 inside\nLine 2: 192.0.2.1 inside\nNetwork: 192.0.2.0/24; inside: 2; outside: 0; invalid: 0\n")
        self.check_bytes(b"\xff", "192.0.2.0/24", 2, error="Check stopped:")

    def test_network_forms(self):
        for network in ["192.0.2.0/255.255.255.0", "192.0.2.0/24"]:
            with self.subTest(network=network):
                self.check_bytes(b"192.0.2.1\n", network, 0,
                                 "Line 1: 192.0.2.1 inside\nNetwork: 192.0.2.0/24; inside: 1; outside: 0; invalid: 0\n")
        self.check_bytes(b"192.0.2.1\n", "192.0.2.1", 0,
                         "Line 1: 192.0.2.1 inside\nNetwork: 192.0.2.1/32; inside: 1; outside: 0; invalid: 0\n")
        for network in ["2001:db8::/32", "bad", "192.0.2.0/33"]:
            with self.subTest(network=network):
                self.check_bytes(b"192.0.2.1\n", network, 2, error="Check stopped:")

    def test_all_addresses_range(self):
        self.check_bytes(b"0.0.0.0\n255.255.255.255\n", "0.0.0.0/0", 0,
                         "Line 1: 0.0.0.0 inside\nLine 2: 255.255.255.255 inside\nNetwork: 0.0.0.0/0; inside: 2; outside: 0; invalid: 0\n")

    def test_line_limit(self):
        result = self.check_bytes(b"192.0.2.1\n" * 1000, "192.0.2.0/24", 0)
        self.assertEqual(len(result.stdout.splitlines()), 1001)
        self.assertTrue(result.stdout.endswith("inside: 1000; outside: 0; invalid: 0\n"))
        self.check_bytes(b"192.0.2.1\n" * 1001, "192.0.2.0/24", 2, error="more than 1000 input lines")

    def test_file_limit(self):
        # Exactly 1 MiB, one oversized invalid address line, no newline.
        self.check_bytes(b"x" * 1048576, "192.0.2.0/24", 1,
                         "Line 1: invalid IPv4 address\nNetwork: 192.0.2.0/24; inside: 0; outside: 0; invalid: 1\n")
        self.check_bytes(b"x" * 1048577, "192.0.2.0/24", 2, error="input exceeds 1 MiB")

    def test_usage_and_missing_file(self):
        result = subprocess.run([sys.executable, str(SCRIPT)], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 2)
        self.assertIn("Usage:", result.stderr)
        with tempfile.TemporaryDirectory() as folder:
            result = subprocess.run([sys.executable, str(SCRIPT), str(Path(folder) / "absent.txt"), "192.0.2.0/24"],
                                    capture_output=True, text=True, timeout=10)
            self.assertEqual(result.returncode, 2)
            self.assertIn("Check stopped:", result.stderr)
            self.assertEqual(result.stdout, "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
