IPv4 subnet practice kit v1.0.0
Tidy Desk Digital

Start here
1. Extract the whole ZIP into a new folder, not over your own files.
2. Review CheckSubnet.py and TestCheckSubnet.py before running them.
3. Use Python 3.10 or later. No extra packages or network access needed.
4. Open a command window in the extracted folder and run:
   python3 CheckSubnet.py addresses.txt 192.0.2.0/24
   Expect 3 inside, 1 outside, 1 invalid, exit code 1.
5. Run: python3 TestCheckSubnet.py
   Expect OK at the end. Tests use disposable copies in a temporary folder,
   then remove the folder. They launch the same Python running the tests.
Use python or py instead if that is your installation's Python 3 command.

Try the same file with different ranges
python3 CheckSubnet.py small-addresses.txt 192.0.2.0/31
Includes .0 and .1, not .2; exit 0.
python3 CheckSubnet.py small-addresses.txt 192.0.2.1/32
Includes only .1; exit 0.
python3 CheckSubnet.py small-addresses.txt 192.0.2.1/24
Stops with host bits set; exit 2. It does not silently change the network.
python3 CheckSubnet.py outside-only.txt 192.0.2.0/24
One outside, no invalid lines, exit 0. Outside is a normal result.
python3 CheckSubnet.py empty.txt 192.0.2.0/24
Zero counts, exit 0. That is not proof that any address was checked.

What the results mean
IPv4 means Internet Protocol version 4. The prefix, for example /24,
defines how many binary digits (bits) identify the address range.
Inside means mathematical membership only. No connection, ping or lookup
is made. It proves no device exists, is reachable, belongs to you or is
allowed through firewall rules. First/last range addresses count as inside;
that does not establish they can be assigned to a device.
All example addresses are fictional documentation ranges, not scan targets.

Exit 0: finished with no invalid lines, including outside-only/empty files.
Exit 1: finished with invalid lines. Exit 2: stopped before completion.
The test runner returns 0 only if all tests pass, otherwise nonzero.
Passing the tests is not a check of your own files, network or permissions.
Do not redirect output over your input file: the shell may erase it first.

Limits
IPv4 only, UTF-8 with optional initial byte-order mark. Python 3.10 or later
rejects extra leading zeros. IPv6 (Internet Protocol version 6) is invalid.
At most 1 MiB (1,048,576 bytes), plus one byte to detect oversized input;
at most 1,000 input lines. Surrounding spaces are removed; blank internal
lines are invalid. A final newline is not another address. Duplicates count
again. Strict network parsing stops when the supplied address is not the
range start for its prefix. A dotted mask is also accepted: 255.255.255.0
means /24. A network address without a mask becomes /32, one address.
Tests cover known cases, not every platform, Python version or file.

Guide and source
https://baptistsec.github.io/guides/ipv4-subnet-membership-python/
https://docs.python.org/3/library/ipaddress.html
https://www.rfc-editor.org/rfc/rfc5737
CheckSubnet.py matches the live guide on 15 October 2026 byte-for-byte:
408beb12b9a57407c293748721ed067036882ee5690cdb2f44d3ad9165de3096
No work data, telemetry or personal paths in this kit.

Licence
MIT License

Copyright (c) 2026 William Baptist

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
