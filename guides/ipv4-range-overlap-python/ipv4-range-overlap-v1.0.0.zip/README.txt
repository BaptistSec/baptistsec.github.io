IPv4 range-overlap checker v1.0.0
Copyright (c) 2026 William Baptist. MIT licence, full text below.

Python 3.10 or later. No extra packages, accounts or network access.
Extract the whole ZIP into a new folder and review the code before running.
Open a command window in that folder, then:
python3 CheckRangeOverlap.py Left.txt Right.txt
Expected: one overlapping pair, left line 1 / right line 1,
192.0.2.128 through 192.0.2.255; 128 addresses. Exit 1.
python3 CheckRangeOverlap.py Left.txt Disjoint.txt
Expected: zero overlapping pairs. Exit 0.
python3 TestRangeOverlap.py
Expected: OK. Nonzero means a test failed or could not run.
Use python or py instead if that is your Python 3 command.

Two lists, one strict IPv4 network/prefix per line. /0 through /32 only,
including a slash even for a single /32 address. Host bits must be zero:
192.0.2.1/24 stops, not silently changed to 192.0.2.0/24. No dotted masks,
comments, blank lines or IPv6. Initial UTF-8 BOM allowed; surrounding spaces
removed. Up to 1 MiB (1,048,576 bytes) and 250 lines per file.
Final newline does not create a blank line. Empty lists stop deliberately.
If either list is invalid, NO findings are printed. No input files changed.

The checker compares every left line with every right line. It does NOT
check overlaps between two lines inside the same list. Give the same file
as both arguments to compare it with itself: each range then overlaps
itself, and two directions of a pair are separate findings. Duplicate
lines count separately. Reports include original line numbers.

A pair's address count includes its first and last addresses. Do not add
counts across pairs: addresses may appear in several findings. Only first
500 pairs have details, in left-then-right input order; summary counts ALL
pairs and says how many details were omitted. At most 62,500 pairs tested.
The program compares range endpoints, never generates a full host list.

Exit 0: completed, no overlapping pairs. Exit 1: completed, overlaps found,
including runs whose detail output was capped. Exit 2: input/command error.
This is a mathematical comparison, not a scan. Overlap can be intentional;
no overlap is not approval of a network change or proof against conflicts.
It checks no devices, routes, firewall rules, ownership or permissions.
It does not identify unused/free address space. Keep reports private: they
show range definitions. Use saved copies that will not change while read.
Never redirect output over an input file: the shell can erase it first.

Fictional ranges are from RFC 5737 documentation space, not scan targets.
Known tests cover range boundaries, invalid input, capped detail, exact
file/line limits and 400 deterministic small-range comparisons against
independent address sets. They do not prove every file/platform/version.
https://docs.python.org/3/library/ipaddress.html
https://www.rfc-editor.org/rfc/rfc5737

Licence
MIT License

Copyright (c) 2026 William Baptist

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
