import importlib.util
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("range_checker", ROOT / "CheckRangeOverlap.py")
checker = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = checker
spec.loader.exec_module(checker)


class OverlapChecks(unittest.TestCase):
    def run_case(self, left, right, code):
        with tempfile.TemporaryDirectory() as folder:
            a, b = Path(folder) / "left list.txt", Path(folder) / "right list.txt"
            a.write_bytes(left); b.write_bytes(right)
            r = subprocess.run([sys.executable, str(ROOT / "CheckRangeOverlap.py"), str(a), str(b)],
                               capture_output=True, text=True, timeout=15)
            self.assertEqual(r.returncode, code, r.stderr)
            self.assertEqual(a.read_bytes(), left); self.assertEqual(b.read_bytes(), right)
            return r

    def test_nested_ranges(self):
        r = self.run_case(b"192.0.2.0/24\n198.51.100.0/24\n", b"192.0.2.128/25\n203.0.113.0/24\n", 1)
        self.assertEqual(r.stderr, "")
        self.assertEqual(r.stdout, "Left line 1 (192.0.2.0/24) / right line 1 (192.0.2.128/25): 192.0.2.128 to 192.0.2.255; 128 addresses\nCompared: 2 left ranges; 2 right ranges; 1 overlapping pairs\nUnique overlapping addresses: 128\n")

    def test_edges_and_disjoint(self):
        self.assertIn("0 overlapping pairs", self.run_case(b"192.0.2.0/31", b"192.0.2.2/31", 0).stdout)
        self.assertIn("1 addresses", self.run_case(b"192.0.2.0/31", b"192.0.2.1/32", 1).stdout)
        self.assertIn("4294967296 addresses", self.run_case(b"0.0.0.0/0", b"0.0.0.0/0", 1).stdout)
        self.assertIn("255.255.255.255 to 255.255.255.255", self.run_case(b"0.0.0.0/0", b"255.255.255.255/32", 1).stdout)

    def test_duplicates_and_same_lists(self):
        r = self.run_case(b"192.0.2.0/24\n192.0.2.0/24", b"192.0.2.0/24\n192.0.2.0/24", 1)
        self.assertIn("4 overlapping pairs", r.stdout)
        self.assertIn("left line 2", r.stdout.lower())

    def test_all_validation_precedes_findings(self):
        for text in [b"", b"\n", b"192.0.2.0/24\n\n", b"192.0.2.1/24", b"192.0.2.0",
                     b"192.0.2.0/255.255.255.0", b"2001:db8::/32", b"192.0.2.0/33",
                     b"192.0.2.0/024", b"192.0.2.00/24", b"# comment", b"\xff",
                     b"192.0.2.0/24\n\x1b[31mgarbage"]:
            with self.subTest(text=text):
                for left,right in [(text,b"0.0.0.0/0"),(b"0.0.0.0/0",text)]:
                    r = self.run_case(left, right, 2)
                    self.assertEqual(r.stdout, "")
                    self.assertIn("Check stopped:", r.stderr)
                    self.assertNotIn("\x1b", r.stderr)

    def test_encoding_and_whitespace(self):
        r = self.run_case(b"\xef\xbb\xbf 192.0.2.0/24 \r\n", b"192.0.2.0/24\n", 1)
        self.assertIn("1 overlapping pairs", r.stdout)

    def test_line_limits_and_detail_cap(self):
        r = self.run_case(b"192.0.2.0/24\n"*250, b"192.0.2.0/24\n"*250, 1)
        self.assertIn("62500 overlapping pairs", r.stdout)
        self.assertIn("62000 pairs omitted", r.stdout)
        self.assertEqual(len(r.stdout.splitlines()), 503)
        self.assertEqual(self.run_case(b"192.0.2.0/24\n"*251, b"192.0.2.0/24", 2).stdout, "")

    def test_size_limit(self):
        # Exactly 1 MiB: one valid network padded with spaces.
        self.assertIn("1 overlapping pairs", self.run_case(b"192.0.2.0/24"+b" "*(1048576-12), b"192.0.2.0/24", 1).stdout)
        r = self.run_case(b"x"*1048577, b"192.0.2.0/24", 2)
        self.assertIn("exceeds 1 MiB", r.stderr)

    def test_missing_and_usage(self):
        with tempfile.TemporaryDirectory() as d:
            r=subprocess.run([sys.executable,str(ROOT/'CheckRangeOverlap.py'),str(Path(d)/'absent'),'absent'],capture_output=True,text=True)
            self.assertEqual(r.returncode,2);self.assertEqual(r.stdout,'')
        r=subprocess.run([sys.executable,str(ROOT/'CheckRangeOverlap.py')],capture_output=True,text=True)
        self.assertEqual(r.returncode,2)

    def test_random_small_ranges_against_sets(self):
        import ipaddress
        rng=random.Random(67121)
        for _ in range(400):
            a=ipaddress.IPv4Network((int(ipaddress.IPv4Address('192.0.2.0'))+rng.randrange(256),rng.randrange(24,33)),strict=False)
            b=ipaddress.IPv4Network((int(ipaddress.IPv4Address('192.0.2.0'))+rng.randrange(256),rng.randrange(24,33)),strict=False)
            expected=set(a)&set(b)
            found=list(checker.intersections([checker.Entry(1,a)],[checker.Entry(2,b)]))
            self.assertEqual(bool(found),bool(expected))
            if expected:
                _,_,start,end,count=found[0]
                self.assertEqual(set(ipaddress.IPv4Address(i) for i in range(int(start),int(end)+1)),expected)
                self.assertEqual(count,len(expected))


    def test_unique_total_for_duplicate_nested_adjacent_and_disjoint(self):
        cases = [
            (b"192.0.2.0/24\n192.0.2.0/24", b"192.0.2.0/24\n192.0.2.128/25", 256),
            (b"192.0.2.0/25\n192.0.2.128/25", b"192.0.2.0/24", 256),
            (b"192.0.2.0/26\n192.0.2.128/26", b"192.0.2.0/24", 128),
            (b"192.0.2.0/31", b"192.0.2.2/31", 0),
            (b"0.0.0.0/0", b"0.0.0.0/0", 4294967296),
            (b"0.0.0.0/0", b"255.255.255.255/32", 1),
        ]
        for left,right,expected in cases:
            with self.subTest(left=left,right=right):
                result=self.run_case(left,right,1 if expected else 0)
                self.assertEqual(result.stdout.splitlines()[-1],f"Unique overlapping addresses: {expected}")

    def test_unique_total_includes_omitted_details(self):
        # First 500 findings have only address .0; a later omitted pair adds .1.
        left=b"192.0.2.0/32\n"*249+b"192.0.2.1/32\n"
        right=b"192.0.2.0/31\n"*3
        result=self.run_case(left,right,1)
        self.assertIn("750 overlapping pairs",result.stdout)
        self.assertIn("250 pairs omitted",result.stdout)
        self.assertTrue(result.stdout.endswith("Unique overlapping addresses: 2\n"))

    def test_unique_random_lists_against_independent_sets(self):
        import ipaddress
        rng=random.Random(19037)
        base=int(ipaddress.IPv4Address('192.0.2.0'))
        for _ in range(300):
            lists=[]
            for side in range(2):
                nets=[ipaddress.IPv4Network((base+rng.randrange(256),rng.randrange(24,33)),strict=False) for _ in range(rng.randrange(1,9))]
                lists.append(nets)
            left_set=set().union(*(set(n) for n in lists[0]))
            right_set=set().union(*(set(n) for n in lists[1]))
            entries=[[checker.Entry(i+1,n) for i,n in enumerate(nets)] for nets in lists]
            pairs=list(checker.intersections(*entries))
            total=checker.unique_address_count([(int(start),int(end)) for _,_,start,end,_ in pairs])
            self.assertEqual(total,len(left_set & right_set))

    def test_interval_merge_edges(self):
        self.assertEqual(checker.unique_address_count([]),0)
        self.assertEqual(checker.unique_address_count([(8,10),(0,2),(2,3),(4,7),(0,0)]),11)
        self.assertEqual(checker.unique_address_count([(0,0),(2,2)]),2)


if __name__ == '__main__':
    unittest.main(verbosity=2)
