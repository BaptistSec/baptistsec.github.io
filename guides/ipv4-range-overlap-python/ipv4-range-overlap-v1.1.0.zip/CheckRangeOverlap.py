"""Compare two saved IPv4 range lists locally. Python 3.10+, no packages."""
import argparse
from dataclasses import dataclass
import ipaddress
from pathlib import Path
import re
import sys

MAX_BYTES = 1048576
MAX_LINES = 250
MAX_FINDINGS = 500
PREFIX = re.compile(r"(?:0|[1-9][0-9]?)\Z")


@dataclass(frozen=True)
class Entry:
    line: int
    network: ipaddress.IPv4Network


def read_list(path):
    with Path(path).open("rb") as source:
        raw = source.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError("file exceeds 1 MiB (1,048,576 bytes)")
    lines = raw.decode("utf-8-sig").splitlines()
    if len(lines) > MAX_LINES:
        raise ValueError("file exceeds 250 lines")
    if not lines:
        raise ValueError("list is empty")
    entries = []
    for number, line in enumerate(lines, 1):
        text = line.strip()
        parts = text.split("/")
        if len(parts) != 2 or not PREFIX.fullmatch(parts[1]):
            raise ValueError(f"line {number}: use an IPv4 network and /0 through /32")
        try:
            network = ipaddress.IPv4Network(text, strict=True)
        except ValueError:
            # Do not echo untrusted lines or terminal escape sequences.
            raise ValueError(f"line {number}: invalid IPv4 network or host bits set") from None
        entries.append(Entry(number, network))
    return entries


def intersections(left, right):
    """Stream pair findings without listing individual addresses."""
    for a in left:
        for b in right:
            if a.network.overlaps(b.network):
                start = max(int(a.network.network_address), int(b.network.network_address))
                end = min(int(a.network.broadcast_address), int(b.network.broadcast_address))
                yield a, b, ipaddress.IPv4Address(start), ipaddress.IPv4Address(end), end - start + 1


def unique_address_count(intervals):
    """Count the union of inclusive integer intervals, not their pair sum."""
    if not intervals:
        return 0
    ordered = sorted(intervals)
    start, end = ordered[0]
    total = 0
    for next_start, next_end in ordered[1:]:
        if next_start <= end + 1:
            end = max(end, next_end)
        else:
            total += end - start + 1
            start, end = next_start, next_end
    return total + end - start + 1


def main(argv=None):
    parser = argparse.ArgumentParser(description="Compare two local IPv4 network lists for overlaps. No network traffic.")
    parser.add_argument("left", help="UTF-8 file: one strict IPv4 network/prefix per line")
    parser.add_argument("right", help="second UTF-8 file; no blank lines or comments")
    args = parser.parse_args(argv)
    lists = []
    # Validate both completely before writing any findings to stdout.
    for side, path in [("left", args.left), ("right", args.right)]:
        try:
            lists.append(read_list(path))
        except (OSError, UnicodeError):
            print(f"Check stopped: {side} list could not be read as UTF-8.", file=sys.stderr)
            return 2
        except ValueError as error:
            print(f"Check stopped: {side} list: {error}", file=sys.stderr)
            return 2
    count = 0
    shared_intervals = []
    for a, b, start, end, size in intersections(*lists):
        count += 1
        shared_intervals.append((int(start), int(end)))
        if count <= MAX_FINDINGS:
            print(f"Left line {a.line} ({a.network}) / right line {b.line} ({b.network}): {start} to {end}; {size} addresses")
    if count > MAX_FINDINGS:
        print(f"Detail limit: first {MAX_FINDINGS} pairs shown; {count - MAX_FINDINGS} pairs omitted.")
    print(f"Compared: {len(lists[0])} left ranges; {len(lists[1])} right ranges; {count} overlapping pairs")
    print(f"Unique overlapping addresses: {unique_address_count(shared_intervals)}")
    return 1 if count else 0


if __name__ == "__main__":
    raise SystemExit(main())
