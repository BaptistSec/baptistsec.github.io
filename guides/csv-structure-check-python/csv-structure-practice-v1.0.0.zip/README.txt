CSV structure practice kit v1.0.0
Tidy Desk Digital

Start here
1. Extract the entire ZIP into a new folder, not over existing work.
2. Review CheckCsv.py before running it. Use Python 3.10 or later.
   No extra packages, account or network access needed.
3. Open a command window in the extracted folder.
4. Run: python3 CheckCsv.py sample.csv
   Expect one mismatch at record 2, ending at line 3, then:
   Columns: 2; matching records: 2; mismatched records: 1
5. Run: python3 CheckCsv.py fixed.csv
   Expect: Columns: 2; matching records: 3; mismatched records: 0
6. Run: python3 TestCheckCsv.py
   Expect all tests to pass and OK at the end. Tests run copies of fictional
   input in a temporary folder and remove that folder when finished.

Use your installation's Python 3 command (python or py) if not python3.
The tests launch the same Python interpreter that runs TestCheckCsv.py.
Every example is fictional. The malformed files are deliberate exercises,
not files to fix in place. All six examples match the online guide's cases;
fixed.csv is sample.csv with Ben's missing field supplied.

Other exercises
python3 CheckCsv.py empty-note.csv       exit 0: one matching record
python3 CheckCsv.py missing-note.csv     exit 1: one mismatch
python3 CheckCsv.py repeated-header.csv  exit 2: repeated header names
python3 CheckCsv.py unfinished.csv       exit 2: unfinished quoted field

Exit 0: finished, field counts match. Exit 1: finished, mismatches found.
Exit 2: stopped; earlier mismatch lines can be partial output.
The test runner returns 0 only if every test passes, otherwise nonzero.
A failure means investigate; it is not a passing check of your own files.
Do not save redirected output over an input file: the shell may erase it.

Limits
Reads at most 1 MiB (1,048,576 bytes), plus a byte to detect oversized input.
At most 1,000 data records and 65,536 characters per field, including header
fields. UTF-8 with optional initial BOM only; comma/double-quote format.
Checks field counts and header spelling, not meanings, formulas, security,
amounts or dates. A semicolon export can look like one matching column.
Never treat exit 0 as approval for a spreadsheet import or payment.
Tests cover known cases, not every CSV file, platform or Python version.

Source and guide
https://baptistsec.github.io/guides/csv-structure-check-python/
https://docs.python.org/3/library/csv.html
CheckCsv.py is byte-for-byte the program embedded in the guide on
15 October 2026. SHA256:
7465cd16f35d03d1bc9c508d67860fa263417308529ece8722c1dbd7783799a7
No work data, telemetry or personal paths are included in this kit.

Licence
MIT License

Copyright (c) 2026 William Baptist

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
