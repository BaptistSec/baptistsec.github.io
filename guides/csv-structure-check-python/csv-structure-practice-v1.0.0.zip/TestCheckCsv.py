"""Run fictional CSV examples in temporary files. No extra packages required."""
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
SCRIPT = ROOT / "CheckCsv.py"


class CsvChecks(unittest.TestCase):
    def check_bytes(self, data, exit_code, stdout=None, error=None):
        with tempfile.TemporaryDirectory(prefix="csv-practice-") as folder:
            source = Path(folder) / "input with spaces.csv"
            source.write_bytes(data)
            before = source.read_bytes()
            result = subprocess.run(
                [sys.executable, str(SCRIPT), str(source)],
                capture_output=True, text=True, timeout=10,
            )
            self.assertEqual(source.read_bytes(), before, "Input changed")
            self.assertEqual(result.returncode, exit_code, result.stderr)
            if stdout is not None:
                self.assertEqual(result.stdout, stdout)
            if error is not None:
                self.assertIn(error, result.stderr)
                self.assertNotIn("Columns:", result.stdout)
            else:
                self.assertEqual(result.stderr, "")
            return result

    def test_pinned_program(self):
        self.assertEqual(hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
                         "7465cd16f35d03d1bc9c508d67860fa263417308529ece8722c1dbd7783799a7")

    def test_guide_examples(self):
        cases = [
            ("sample.csv", 1, "Record 2, ending at line 3: expected 2 fields, found 1\nColumns: 2; matching records: 2; mismatched records: 1\n", None),
            ("fixed.csv", 0, "Columns: 2; matching records: 3; mismatched records: 0\n", None),
            ("empty-note.csv", 0, "Columns: 2; matching records: 1; mismatched records: 0\n", None),
            ("missing-note.csv", 1, "Record 1, ending at line 2: expected 2 fields, found 1\nColumns: 2; matching records: 0; mismatched records: 1\n", None),
            ("repeated-header.csv", 2, "", "header contains repeated names"),
            ("unfinished.csv", 2, "", "unexpected end of data"),
        ]
        for name, code, out, err in cases:
            with self.subTest(file=name):
                source = ROOT / name
                before = source.read_bytes()
                self.check_bytes(before, code, out, err)
                self.assertEqual(source.read_bytes(), before)

    def test_headers(self):
        for data, err in [(b"", "empty input"), (b"\n", "blank name"),
                          (b"A, \n", "blank name"), (b"A,A\n", "repeated names")]:
            with self.subTest(data=data):
                self.check_bytes(data, 2, "", err)
        self.check_bytes(b"A,a, A \n1,2,3\n", 0,
                         "Columns: 3; matching records: 1; mismatched records: 0\n")
        self.check_bytes(b"A,B\n", 0,
                         "Columns: 2; matching records: 0; mismatched records: 0\n")

    def test_blank_record(self):
        self.check_bytes(b"A,B\n\n", 1,
                         "Record 1, ending at line 2: expected 2 fields, found 0\nColumns: 2; matching records: 0; mismatched records: 1\n")

    def test_encoding_and_newlines(self):
        for data in [b"\xef\xbb\xbfA,B\r\n1,2\r\n", b'A,B\n1,"two\nlines"\n']:
            with self.subTest(data=data):
                self.check_bytes(data, 0, "Columns: 2; matching records: 1; mismatched records: 0\n")
        self.check_bytes(b"A\n\xff\n", 2, "", "Check stopped:")

    def test_field_limit(self):
        self.check_bytes(b"A\n" + b"x" * 65536 + b"\n", 0,
                         "Columns: 1; matching records: 1; mismatched records: 0\n")
        self.check_bytes(b"A\n" + b"x" * 65537 + b"\n", 2, "", "field larger than field limit")
        self.check_bytes(b"x" * 65536 + b"\na\n", 0,
                         "Columns: 1; matching records: 1; mismatched records: 0\n")
        self.check_bytes(b"x" * 65537 + b"\na\n", 2, "", "field larger than field limit")

    def test_record_limit(self):
        self.check_bytes(b"A\n" + b"x\n" * 1000, 0,
                         "Columns: 1; matching records: 1000; mismatched records: 0\n")
        self.check_bytes(b"A\n" + b"x\n" * 1001, 2, "", "more than 1000 data records")

    def test_file_limit(self):
        # Exactly 1 MiB; 16 fields keep each field below its separate limit.
        data = b"A\n" + b",".join([b"x" * 65535] * 15 + [b"x" * 65534])
        self.assertEqual(len(data), 1048576)
        self.check_bytes(data, 1, "Record 1, ending at line 2: expected 1 fields, found 16\nColumns: 1; matching records: 0; mismatched records: 1\n")
        self.check_bytes(data + b"x", 2, "", "input exceeds 1 MiB")

    def test_partial_output(self):
        self.check_bytes(b'A,B\nwrong\n"unfinished\n', 2,
                         "Record 1, ending at line 2: expected 2 fields, found 1\n",
                         "unexpected end of data")

    def test_semicolon_is_not_detected(self):
        self.check_bytes(b"A;B\n1;2\n", 0,
                         "Columns: 1; matching records: 1; mismatched records: 0\n")

    def test_usage_and_missing_file(self):
        result = subprocess.run([sys.executable, str(SCRIPT)], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 2)
        self.assertIn("Usage:", result.stderr)
        with tempfile.TemporaryDirectory() as folder:
            result = subprocess.run([sys.executable, str(SCRIPT), str(Path(folder) / "absent.csv")],
                                    capture_output=True, text=True, timeout=10)
            self.assertEqual(result.returncode, 2)
            self.assertIn("Check stopped:", result.stderr)
            self.assertEqual(result.stdout, "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
